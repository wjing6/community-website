module.exports = {
  extends: ['taro/react', 'tencent', 'prettier'],
  plugins: ['prettier'],
};
