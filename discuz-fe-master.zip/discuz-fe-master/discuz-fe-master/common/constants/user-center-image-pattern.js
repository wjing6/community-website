export const USER_IMAGE_TYPES = [ //上传头像格式
    'image/jpg',
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/heic',
  ];