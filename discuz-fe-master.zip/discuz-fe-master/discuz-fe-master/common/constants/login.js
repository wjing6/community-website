/**
 * 登录注册相关常量
 */

// 用户状态值
export const USER_STATUS = {
  SUPPLEMENTARY: 10
}